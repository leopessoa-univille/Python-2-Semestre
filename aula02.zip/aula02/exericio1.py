notas=[]
while True:
    cnt = input("Deseja informar uma nota? ")
    if cnt =='nao':
        break
    nota = float(input("Digite a nota: "))
    notas.append(nota)

print(notas)

media = 0
for elemento in notas:
    media = media + elemento

media = media / len(notas)
print(media)