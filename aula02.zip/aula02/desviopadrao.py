
lista = [1,2,3,4,5,4,5,2,3,4,5,6,4]
media = 0 
for e in lista:
    media = media + e

media /= len(lista)
print(media)

somatorio = 0
for j in lista:
    somatorio = somatorio + pow(j - media,2) 

somatorio = somatorio / 2
desvio_padrao = sqrt(somatorio)
print(desvio_padrao)